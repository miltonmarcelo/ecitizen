import {
  Plus,
  Clock,
  CheckCircle2,
  AlertCircle,
  MapPin,
  ChevronRight,
  Zap,
  Lightbulb,
  Trash2,
  ThumbsUp,
  ArrowRight,
  History,
} from "lucide-react";
import { motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import TopBar from "@/components/TopBar";
import { useAuth } from "@/context/AuthContext";

type ApiCategory = {
  id: number;
  name: string;
  description?: string | null;
  isActive?: boolean;
};

type ApiIssue = {
  id: number;
  caseId: string;
  title: string;
  description: string;
  categoryId: number | null;
  category: ApiCategory | null;
  status: "CREATED" | "UNDER_REVIEW" | "IN_PROGRESS" | "RESOLVED" | "CLOSED" | "CANCELLED";
  addressLine1: string;
  addressLine2?: string | null;
  town: string;
  city: string;
  county: string;
  eircode: string;
  createdAt: string;
  updatedAt: string;
};

const NEARBY_ISSUES = [
  {
    id: 4,
    icon: Zap,
    title: "Power outage in Block C",
    area: "Block C, 0.3 km away",
    supporters: 12,
    status: "Open",
    statusColor: "bg-primary/15 text-primary",
  },
  {
    id: 5,
    icon: Trash2,
    title: "Illegal dumping near river",
    area: "River Road, 0.8 km away",
    supporters: 8,
    status: "In Progress",
    statusColor: "bg-warning/15 text-warning",
  },
  {
    id: 6,
    icon: Lightbulb,
    title: "Faulty traffic signal",
    area: "Oak Avenue, 1.2 km away",
    supporters: 5,
    status: "Open",
    statusColor: "bg-primary/15 text-primary",
  },
];

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 14 },
  animate: { opacity: 1, y: 0 },
  transition: { delay, duration: 0.4 },
});

const getStatusLabel = (status: ApiIssue["status"]) => {
  switch (status) {
    case "CREATED":
      return "Open";
    case "UNDER_REVIEW":
      return "Under Review";
    case "IN_PROGRESS":
      return "In Progress";
    case "RESOLVED":
      return "Resolved";
    case "CLOSED":
      return "Closed";
    case "CANCELLED":
      return "Cancelled";
    default:
      return status;
  }
};

const getStatusColor = (status: ApiIssue["status"]) => {
  switch (status) {
    case "RESOLVED":
    case "CLOSED":
      return "bg-accent/15 text-accent";
    case "IN_PROGRESS":
    case "UNDER_REVIEW":
      return "bg-warning/15 text-warning";
    case "CANCELLED":
      return "bg-destructive/15 text-destructive";
    case "CREATED":
    default:
      return "bg-primary/15 text-primary";
  }
};

const buildLocation = (issue: ApiIssue) => {
  return [issue.addressLine1, issue.town, issue.city].filter(Boolean).join(", ");
};

const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleDateString("en-IE", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
};

const DashboardPage = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  const [issues, setIssues] = useState<ApiIssue[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchIssues = async () => {
      try {
        setLoading(true);

        if (!user) {
          setIssues([]);
          return;
        }

        const token = await user.getIdToken();

        const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/issues/my`, {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.message || "Failed to fetch dashboard issues");
        }

        setIssues(Array.isArray(data.issues) ? data.issues : []);
      } catch (error) {
        console.error("Dashboard fetch error:", error);
        setIssues([]);
      } finally {
        setLoading(false);
      }
    };

    if (!authLoading) {
      fetchIssues();
    }
  }, [user, authLoading]);

  const stats = useMemo(() => {
    const createdCount = issues.length;

    const inProgressCount = issues.filter(
      (issue) =>
        issue.status !== "RESOLVED" &&
        issue.status !== "CLOSED" &&
        issue.status !== "CANCELLED"
    ).length;

    const resolvedCount = issues.filter(
      (issue) => issue.status === "RESOLVED" || issue.status === "CLOSED"
    ).length;

    return [
      {
        label: "Created",
        value: createdCount,
        icon: AlertCircle,
        color: "text-primary",
        bg: "bg-primary/10",
      },
      {
        label: "In Progress",
        value: inProgressCount,
        icon: Clock,
        color: "text-warning",
        bg: "bg-warning/10",
      },
      {
        label: "Resolved",
        value: resolvedCount,
        icon: CheckCircle2,
        color: "text-accent",
        bg: "bg-accent/10",
      },
    ];
  }, [issues]);

  const recentIssues = useMemo(() => {
    return [...issues]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 3);
  }, [issues]);

  const latestIssue = useMemo(() => {
    if (issues.length === 0) return null;

    return [...issues].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    )[0];
  }, [issues]);

  const quickActions = [
    {
      icon: History,
      label: "See My Latest Report",
      color: "text-primary",
      onClick: () => {
        if (latestIssue) {
          navigate(`/issue/${latestIssue.caseId}`);
        }
      },
      disabled: !latestIssue,
    },
    {
      icon: AlertCircle,
      label: "Report Pothole",
      color: "text-primary",
      onClick: () => navigate("/report?category=Pothole"),
      disabled: false,
    },
    {
      icon: Lightbulb,
      label: "Streetlight Issue",
      color: "text-warning",
      onClick: () => navigate("/report?category=Street%20Light"),
      disabled: false,
    },
    {
      icon: Trash2,
      label: "Waste Issue",
      color: "text-accent",
      onClick: () => navigate("/report?category=Waste"),
      disabled: false,
    },
  ];

  const userName =
    user?.displayName?.trim() ||
    (user?.email ? user.email.split("@")[0] : "there");

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <TopBar showProfile />

      <main className="flex-1 px-4 py-6 max-w-lg mx-auto w-full space-y-6">
        <motion.div {...fadeUp(0)}>
          <h1 className="text-xl font-bold text-foreground">Hello, {userName}</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Report and track local issues easily
          </p>
          <div className="flex gap-3 mt-4">
            <button
              onClick={() => navigate("/report")}
              className="btn-primary-civic flex-1 flex items-center justify-center gap-2 text-sm"
            >
              <Plus size={16} /> Report New Issue
            </button>
            <button
              onClick={() => navigate("/my-issues")}
              className="flex-1 flex items-center justify-center gap-2 text-sm rounded-xl border border-border bg-card px-4 py-2.5 font-medium text-foreground hover:bg-muted transition-colors"
            >
              View My Issues
            </button>
          </div>
        </motion.div>

        <motion.div {...fadeUp(0.1)}>
          <div className="grid grid-cols-3 gap-2.5">
            {stats.map((stat) => (
              <div
                key={stat.label}
                className="card-civic flex flex-col items-center py-3 px-1 text-center"
              >
                <div className={`w-8 h-8 rounded-full ${stat.bg} flex items-center justify-center mb-1.5`}>
                  <stat.icon size={15} className={stat.color} />
                </div>
                <span className="text-lg font-bold text-foreground leading-none">
                  {loading ? "..." : stat.value}
                </span>
                <span className="text-[10px] text-muted-foreground mt-0.5 leading-tight">
                  {stat.label}
                </span>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div {...fadeUp(0.2)}>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-foreground">My Recent Issues</h2>
            <button
              onClick={() => navigate("/my-issues")}
              className="text-xs text-primary font-medium hover:underline flex items-center gap-0.5"
            >
              View all <ChevronRight size={12} />
            </button>
          </div>

          <div className="space-y-2.5">
            {recentIssues.length === 0 ? (
              <div className="card-civic">
                <p className="text-sm text-muted-foreground">
                  {loading ? "Loading your issues..." : "No issues reported yet."}
                </p>
              </div>
            ) : (
              recentIssues.map((issue) => (
                <div key={issue.id} className="card-civic flex items-start gap-3">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{issue.title}</p>
                    <div className="flex items-center gap-1.5 mt-1">
                      <MapPin size={11} className="text-muted-foreground shrink-0" />
                      <span className="text-xs text-muted-foreground truncate">
                        {buildLocation(issue)}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-2">
                      <span
                        className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${getStatusColor(issue.status)}`}
                      >
                        {getStatusLabel(issue.status)}
                      </span>
                      <span className="text-[10px] text-muted-foreground">
                        {formatDate(issue.createdAt)}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => navigate(`/issue/${issue.caseId}`)}
                    className="shrink-0 text-xs text-primary font-medium hover:underline mt-1"
                  >
                    View
                  </button>
                </div>
              ))
            )}
          </div>
        </motion.div>

        <motion.div {...fadeUp(0.3)}>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-foreground">Issues Near Me</h2>
            <button
              onClick={() => navigate("/area-issues")}
              className="text-xs text-primary font-medium hover:underline flex items-center gap-0.5"
            >
              View all <ChevronRight size={12} />
            </button>
          </div>
          <div className="space-y-2.5">
            {NEARBY_ISSUES.map((issue) => (
              <div key={issue.id} className="card-civic flex items-start gap-3">
                <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                  <issue.icon size={16} className="text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{issue.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{issue.area}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${issue.statusColor}`}>
                      {issue.status}
                    </span>
                    <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                      <ThumbsUp size={10} /> {issue.supporters} supporters
                    </span>
                  </div>
                </div>
                <button onClick={() => navigate("/area-issues")} className="shrink-0 mt-1">
                  <ArrowRight
                    size={14}
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  />
                </button>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div {...fadeUp(0.4)}>
          <h2 className="text-sm font-semibold text-foreground mb-3">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-2.5">
            {quickActions.map((action) => (
              <button
                key={action.label}
                onClick={action.onClick}
                disabled={action.disabled}
                className={`card-civic flex items-center gap-3 text-left transition-colors ${
                  action.disabled
                    ? "opacity-50 cursor-not-allowed"
                    : "hover:bg-muted/40"
                }`}
              >
                <div className="w-9 h-9 rounded-full bg-muted flex items-center justify-center shrink-0">
                  <action.icon size={16} className={action.color} />
                </div>
                <span className="text-sm font-medium text-foreground">{action.label}</span>
              </button>
            ))}
          </div>
        </motion.div>
      </main>
    </div>
  );
};

export default DashboardPage;